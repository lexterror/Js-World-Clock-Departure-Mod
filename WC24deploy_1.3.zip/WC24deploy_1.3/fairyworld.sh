#!/data/data/com.termux/files/usr/bin/bash

while true; do

    echo "" > worldclockdata.txt
    printf "\033c"
    Airports=("PPG" "HNL" "ADK" "YAK" "LAX" "DEN" "MCI" "BOS" "REC" "GOH" "SID" "PDL" "LHR" "MAD" "SVO" "GYD" "KHI" "DAC" "BKK" "HKG" "HND" "POM" "SYD" "NAN");
    i=0
    for tz in  Pacific/Pago_Pago Pacific/Honolulu America/Adak  America/Yakutat US/Pacific America/Denver US/Central US/Eastern  America/Recife America/Godthab  Atlantic/Cape_Verde Atlantic/Azores Europe/London Europe/Madrid Europe/Moscow Asia/Baku Asia/Karachi Asia/Dhaka Asia/Bangkok Asia/Hong_Kong Asia/Tokyo  Pacific/Port_Moresby  Australia/Sydney Pacific/Fiji; do
    echo -e  "$(TZ=$tz date '+%z') $(TZ=$tz date '+%a %d-%b, %Y %I:%M %p') : ${Airports[$i]}" >>  worldclockdata.txt
    i=$((i+1))
    #echo "" >> worldclockdata.txt
    done
    
    am broadcast -a net.dinglish.tasker.updatewidget --user 0 >/dev/null
    sleep $((60 - $(date +%s) % 60))
 
done